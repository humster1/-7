import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.ln

fun main() {
    println("Первое число?")
    val s: String? = readLine()
    var a: Double = s!!.toDouble()
    println("Второе число?")
    val q: String? = readLine()
    var b: Double = q!!.toDouble()
    println("Третье число?")
    val w: String? = readLine()
    var c: Double = w!!.toDouble()
    println("Четвертое число?")
    val e: String? = readLine()
    var d: Double = e!!.toDouble()
    println("Пятое число?")
    val o: String? = readLine()
    var n: Int = o!!.toInt()
    n += 3
    var y: Double = 10.0
        y = y.pow(n)
    var result: Double = 0.25*(a - b) / (1/8 - (abs(b) / y + (ln(b))/ c - d))
    println("Ответ: $result")
}
