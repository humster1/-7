fun main() {
    println("Введи трехзначное число")
    val s: String? = readLine()
    var X: Int = s!!.toInt()
    var a: Int = 0
    var b: Int = 0
    var c: Int = 0
    a = X % 10
    b = (X / 10)%10
    c = (X / 100) % 10
    val sum: Int = a + b +c
    val proiz: Int = a * b * c
    println("Сумма цифр = $sum " +
            " Произведение цифр = $proiz")
}