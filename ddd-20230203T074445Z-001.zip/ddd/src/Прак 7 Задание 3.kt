fun main() {
    println("Первый член?")
    val s: String? = readLine()
    var X: Double = s!!.toDouble()
    println("Знаменанатель геометрической прогрессии")
    val r: String? = readLine()
    var Y: Double = r!!.toDouble()
    println("От какого члена последовательности")
    val q: String? = readLine()
    var N: Int = q!!.toInt()
    println("До какого члена последовательности")
    val t: String? = readLine()
    var L: Int = t!!.toInt()
    var result: Double = 0.0
    if(L > N)
    {
        for (i in N..L)
        {
            result += ((X * i) * Y - X) / (Y - 1)
        }
        println("Ответ: $result")
    } else println("Ошибка")

}